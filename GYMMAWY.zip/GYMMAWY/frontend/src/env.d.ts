/// <reference types="vite/client" />


